var d = new Date();
document.getElementById("datetime").innerHTML = d;