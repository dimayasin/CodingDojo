from __future__ import unicode_literals

from django.shortcuts import render,redirect,HttpResponse
from django.contrib import messages
import bcrypt
from .models import Users
from .models import Wishlist
import datetime

secret_key = 'TARDIS' 

def index(request):
    users = Users.objects.all()


    request.session['id']=0
    request.session['name']=""
    request.session['item_id'] = 0
    # request.session['fav'] = []

    context ={
        'users': users
    }
    return render(request, "index.html",context)


def log(request):
    return render(request,"login.html")


def logins(request):
    errors = Users.objects.validateLoginData(request.POST)
    if len(errors)>0:
        for error in errors:
            messages.error(request,error)
        return render(request,"login.html")
    else:
 
        users = Users.objects.filter(username = request.POST['username'])[0]
        request.session['id'] = users.id
        request.session['name'] = users.name 

        context={
            'users': users
        }
        return redirect("/show", context)

def new_user(request):
    return render(request,"registration.html")

def Registration(request):
    errors = Users.objects.validateRegistrationData(request.POST)
    if len(errors)>0:
        for error in errors:
            messages.error(request,error)
        return render(request,"registration.html")
    else:
        hasher1 = bcrypt.hashpw(request.POST['psswrd'].encode(), bcrypt.gensalt())
        Users.objects.create( 
            name=request.POST['name'],
            username=request.POST['username'], 
            password=hasher1, 
            # DOB= datetime.datetime.strptime(request.POST['DOB'], '%Y-%m-%d')
            )
        users = Users.objects.filter(username = request.POST['username'])[0]
        context={
            'users': users
        }
        request.session['id'] = users.id
        request.session['name'] = users.name 

        return redirect("/show", context)

def show(request):
    show_list = Wishlist.objects.filter()
    myfav=[]
    notfav=[]
    for myitem in show_list:
        if myitem.favorite == True or myitem.added_by.name == request.session['name']:
            myfav += Wishlist.objects.filter(id=myitem.id)
        else:
            notfav +=Wishlist.objects.filter(id=myitem.id)
    

    context={
            'items' : notfav,
            'favorites':myfav 
        }
 
    return render(request, "wishlist.html", context)

def new_item(request):
    return render(request,"new_list_item.html")

def additem(request):
    errors = Wishlist.objects.ValidateWishList(request.POST)


    if len (errors)>0:
        for error in errors:   
            messages.error(request,error)
        return render(request,"wishlist.html")

    else:
        user = Users.objects.get(id = request.session['id'])
        Wishlist.objects.create( 
            item=request.POST['item'],
            date= datetime.date.today(), 
            added_by= user
        )
        
        wish = Wishlist.objects.filter()
        # request.session['id'] = user.id
        # request.session['name'] = user.name
        context={
            'wishes': wish
        }
        return redirect("/show", context)

def remove(request, id):
    request.session['item_id'] = id
    mylist = Wishlist.objects.get(id=id)
    if mylist.added_by.id == request.session['id']:

        mylist = Wishlist.objects.get(id=request.session['item_id'])
        mylist.delete()

    else:
        messages.error(request,"User doesn't have permission to remove this course")
    return redirect("/show")
def delete(request):
    mylist = Wishlist.objects.get(id=request.session['item_id'])
    mylist.delete()
    return redirect("/show")

def favorites(request, id):

    myfav = Wishlist.objects.get(id=id)
    myfav.favorite = True
    myfav.save()

    return redirect("/show")

def notfavorite(request, id):

    Nofav = Wishlist.objects.get(id=id)
    Nofav.favorite = False
    Nofav.save()

    return redirect("/show")
    

def out(request):
    request.session.clear()
    return redirect ("/log")